package com.example.Just_Learning_React;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JustLearningReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
